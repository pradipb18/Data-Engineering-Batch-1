def square(x):
    return x ** 2

# lambda function
square_lambda = lambda x: x ** 2

print(square(5))
print(square_lambda(5))

# Using lambda with map to square each element
numbers = [1, 2, 3, 4, 5]

squared_numbers = list(map(lambda x: x**2, numbers))

print(squared_numbers)
