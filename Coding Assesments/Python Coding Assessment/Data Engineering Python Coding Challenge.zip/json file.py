import json

json_file_path = r'C:\Users\pmboc\Downloads\sample1.json'


with open(json_file_path, 'r') as file:
    python_object = json.load(file)


print(python_object)
