
import pandas as pd

# Defining path of the CSV file from the local system

file_path = r'C:\Users\pmboc\Downloads\Employees.csv'


df = pd.read_csv(file_path)

print(df)

print(df.Name)
