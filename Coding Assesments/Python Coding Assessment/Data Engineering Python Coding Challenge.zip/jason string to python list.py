import json

# jason string
json_string = '{"name": "Pradip", "age": 24, "city": "Pune"}'

python_dict = json.loads(json_string)

print(python_dict)

import json

# jason string representing a list
json_string_list = '[1, 2, 3, 4, 5]'

python_list = json.loads(json_string_list)

print(python_list)

