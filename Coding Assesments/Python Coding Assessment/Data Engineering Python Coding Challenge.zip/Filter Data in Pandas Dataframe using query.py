import pandas as pd

data = {'Name': ['Pradip', 'Vedant', 'Abhishek', 'Vinay', 'Vikrant'],
        'Age': [25, 24, 28, 30, 29],
        'City': ['Majalgaon', 'Kalamb', 'Akola', 'Latur', 'Nagpur']}

df = pd.DataFrame(data)

filtered_df = df.query('Age > 25 and City == "Nagpur"')

print(filtered_df)

age_threshold = 25
city_name = 'Akola'

filtered_df1 = df.query(f'Age > {age_threshold} and City == "{city_name}"')

print(filtered_df1)